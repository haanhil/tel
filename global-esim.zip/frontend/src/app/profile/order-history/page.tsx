import React from 'react';

import OrderHistoryPage from '@/components/OrderHistoryPage';

const page = () => {
    return (
        <div>
            <OrderHistoryPage />
        </div>
    );
};

export default page;
