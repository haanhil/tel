import React from 'react';

import PrivacyPolicy from '@/components/common/PrivacyPolicy';

const page = () => {
    return (
        <div>
            <PrivacyPolicy />
        </div>
    );
};

export default page;
