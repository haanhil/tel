import React from 'react';

import TermsAndConditionsPage from '@/components/common/TermsAndConditionsPage';

const page = () => {
    return (
        <div>
            <TermsAndConditionsPage />
        </div>
    );
};

export default page;
