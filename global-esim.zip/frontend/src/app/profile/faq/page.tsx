import React from 'react';

import FAQ from '@/components/sections/FAQ';

const page = () => {
    return (
        <div>
            <FAQ />
        </div>
    );
};

export default page;
