<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Services\AiraloService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;

class CronJobController extends Controller
{
    public function getPackagesAiralo(Request $request,AiraloService $airaloService)
    {

    }
}
